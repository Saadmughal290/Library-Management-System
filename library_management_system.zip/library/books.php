<?php
require_once 'includes/config.php';
$page_title = 'Books';

// Search & filter
$search = isset($_GET['search']) ? sanitize($conn, $_GET['search']) : '';
$category = isset($_GET['category']) ? sanitize($conn, $_GET['category']) : '';

// Pagination
$per_page = 9;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $per_page;

// Build query
$where = "WHERE 1=1";
if ($search) $where .= " AND (title LIKE '%$search%' OR author LIKE '%$search%' OR isbn LIKE '%$search%')";
if ($category) $where .= " AND category = '$category'";

$total_books = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM books $where"))[0];
$total_pages = ceil($total_books / $per_page);

$books = mysqli_query($conn, "SELECT * FROM books $where ORDER BY title ASC LIMIT $per_page OFFSET $offset");

// Get categories
$cats_result = mysqli_query($conn, "SELECT DISTINCT category FROM books ORDER BY category");
$categories = [];
while ($c = mysqli_fetch_row($cats_result)) $categories[] = $c[0];
?>
<?php include 'includes/header.php'; ?>

<div class="page-header">
    <h1>📚 Book Catalogue</h1>
    <p>Explore our collection of <?php echo $total_books; ?> books</p>
</div>

<section class="section">
    <div class="container">

        <!-- Search Bar -->
        <form method="GET" class="search-bar">
            <input type="text" name="search" class="form-control" placeholder="Search by title, author, or ISBN..." value="<?php echo htmlspecialchars($search); ?>">
            <select name="category" class="form-control">
                <option value="">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                <option value="<?php echo $cat; ?>" <?php echo $category === $cat ? 'selected' : ''; ?>><?php echo $cat; ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary">Search</button>
            <?php if ($search || $category): ?>
            <a href="books.php" class="btn btn-outline">Clear</a>
            <?php endif; ?>
        </form>

        <?php if (mysqli_num_rows($books) === 0): ?>
        <div class="alert alert-info">No books found matching your search.</div>
        <?php else: ?>

        <div class="card-grid">
            <?php while ($book = mysqli_fetch_assoc($books)): ?>
            <div class="card">
                <div class="card-cover">📖</div>
                <div class="card-body">
                    <div class="card-category"><?php echo htmlspecialchars($book['category']); ?></div>
                    <div class="card-title"><?php echo htmlspecialchars($book['title']); ?></div>
                    <div class="card-author">by <?php echo htmlspecialchars($book['author']); ?> (<?php echo $book['published_year']; ?>)</div>
                    <p style="font-size:0.82rem;color:#666;line-height:1.5;margin-bottom:0.8rem;">
                        <?php echo htmlspecialchars(substr($book['description'], 0, 100)) . '...'; ?>
                    </p>
                    <div style="font-size:0.8rem;color:#888;margin-bottom:0.5rem;">
                        <strong>ISBN:</strong> <?php echo htmlspecialchars($book['isbn']); ?> &nbsp;|&nbsp;
                        <strong>Copies:</strong> <?php echo $book['total_copies']; ?>
                    </div>
                    <div class="card-footer">
                        <span class="badge <?php echo $book['available_copies'] > 0 ? 'badge-available' : 'badge-unavailable'; ?>">
                            <?php echo $book['available_copies'] > 0 ? $book['available_copies'] . ' Available' : 'Unavailable'; ?>
                        </span>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
            <a href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category); ?>">← Prev</a>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category); ?>" class="<?php echo $i === $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>
            <?php if ($page < $total_pages): ?>
            <a href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($category); ?>">Next →</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
