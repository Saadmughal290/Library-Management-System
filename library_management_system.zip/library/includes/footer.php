<footer class="footer">
    <div class="footer-inner">
        <div class="footer-brand">
            <span class="logo-icon">📚</span>
            <strong><?php echo SITE_NAME; ?></strong>
            <p>Your gateway to knowledge and learning.</p>
        </div>
        <div class="footer-links">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="<?php echo SITE_URL; ?>/index.php">Home</a></li>
                <li><a href="<?php echo SITE_URL; ?>/books.php">Books</a></li>
                <li><a href="<?php echo SITE_URL; ?>/members.php">Members</a></li>
                <li><a href="<?php echo SITE_URL; ?>/contact.php">Contact</a></li>
            </ul>
        </div>
        <div class="footer-contact">
            <h4>Contact Us</h4>
            <p>📍 FAST-NUCES, Islamabad</p>
            <p>📧 library@libravault.pk</p>
            <p>📞 051-111-128-128</p>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved. | CSC 337 Assignment 3</p>
    </div>
</footer>

<script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
