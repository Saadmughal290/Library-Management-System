<?php
// includes/header.php
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' — ' . SITE_NAME : SITE_NAME; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <a href="<?php echo SITE_URL; ?>/index.php" class="nav-logo">
        <span class="logo-icon">📚</span>
        <span><?php echo SITE_NAME; ?></span>
    </a>
    <ul class="nav-links">
        <li><a href="<?php echo SITE_URL; ?>/index.php" class="<?php echo $current_page==='index'?'active':''; ?>">Home</a></li>
        <li><a href="<?php echo SITE_URL; ?>/books.php" class="<?php echo $current_page==='books'?'active':''; ?>">Books</a></li>
        <li><a href="<?php echo SITE_URL; ?>/members.php" class="<?php echo $current_page==='members'?'active':''; ?>">Members</a></li>
        <li><a href="<?php echo SITE_URL; ?>/about.php" class="<?php echo $current_page==='about'?'active':''; ?>">About</a></li>
        <li><a href="<?php echo SITE_URL; ?>/contact.php" class="<?php echo $current_page==='contact'?'active':''; ?>">Contact</a></li>
        <li><a href="<?php echo SITE_URL; ?>/admin/login.php" class="btn-admin">Admin Panel</a></li>
    </ul>
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
</nav>
