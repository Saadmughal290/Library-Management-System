<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // Change to your MySQL username
define('DB_PASS', '');            // Change to your MySQL password
define('DB_NAME', 'library_db');

// Site Configuration
define('SITE_NAME', 'LibraVault');
define('SITE_URL', 'http://localhost/library');
define('FINE_PER_DAY', 5); // PKR fine per overdue day

// Create connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if (!$conn) {
    die('<div style="font-family:sans-serif;padding:40px;color:#c00;">
        <h2>Database Connection Failed</h2>
        <p>' . mysqli_connect_error() . '</p>
        <p>Please check your database settings in <code>includes/config.php</code></p>
    </div>');
}

mysqli_set_charset($conn, "utf8");

// Session start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Helper functions
function sanitize($conn, $data) {
    return mysqli_real_escape_string($conn, htmlspecialchars(trim($data)));
}

function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

function requireAdmin() {
    if (!isAdminLoggedIn()) {
        header('Location: ' . SITE_URL . '/admin/login.php');
        exit();
    }
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function timeAgo($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff/60) . ' min ago';
    if ($diff < 86400) return floor($diff/3600) . ' hr ago';
    return date('d M Y', $time);
}
?>
