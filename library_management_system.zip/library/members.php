<?php
require_once 'includes/config.php';
$page_title = 'Members';

$search = isset($_GET['search']) ? sanitize($conn, $_GET['search']) : '';
$where = $search ? "WHERE name LIKE '%$search%' OR email LIKE '%$search%'" : "";
$members = mysqli_query($conn, "SELECT m.*, (SELECT COUNT(*) FROM borrow_records br WHERE br.member_id=m.id AND br.status='borrowed') as active_borrows FROM members m $where ORDER BY m.name ASC");
$total = mysqli_num_rows($members);
?>
<?php include 'includes/header.php'; ?>

<div class="page-header">
    <h1>👥 Library Members</h1>
    <p><?php echo $total; ?> registered members</p>
</div>

<section class="section">
    <div class="container">

        <form method="GET" class="search-bar">
            <input type="text" name="search" class="form-control" placeholder="Search members by name or email..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
            <?php if ($search): ?><a href="members.php" class="btn btn-outline">Clear</a><?php endif; ?>
        </form>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Member Since</th>
                        <th>Active Borrows</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($members) === 0): ?>
                    <tr><td colspan="7" style="text-align:center;padding:2rem;color:#888;">No members found.</td></tr>
                <?php else: ?>
                <?php $i = 1; while ($m = mysqli_fetch_assoc($members)): ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><strong><?php echo htmlspecialchars($m['name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($m['email']); ?></td>
                        <td><?php echo htmlspecialchars($m['phone']); ?></td>
                        <td><?php echo date('d M Y', strtotime($m['membership_date'])); ?></td>
                        <td>
                            <?php if ($m['active_borrows'] > 0): ?>
                            <span class="badge badge-borrowed"><?php echo $m['active_borrows']; ?> book(s)</span>
                            <?php else: ?>
                            <span style="color:#888;">—</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge badge-<?php echo $m['status']; ?>"><?php echo ucfirst($m['status']); ?></span></td>
                    </tr>
                <?php endwhile; endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</section>

<?php include 'includes/footer.php'; ?>
