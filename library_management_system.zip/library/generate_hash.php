<?php
// Run this file ONCE in your browser: http://localhost/library/generate_hash.php
// Copy the hash and update your admins table.

$password = 'admin123';
$hash = password_hash($password, PASSWORD_BCRYPT);

echo "<pre>";
echo "Password: $password\n";
echo "Hash: $hash\n\n";
echo "Run this SQL to update admin password:\n";
echo "UPDATE admins SET password='$hash' WHERE username='admin';\n";
echo "</pre>";
echo "<p><a href='admin/login.php'>Go to Admin Login</a></p>";
?>
