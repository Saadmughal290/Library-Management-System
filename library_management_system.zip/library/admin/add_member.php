<?php
require_once '../includes/config.php';
$page_title = 'Add Member';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = sanitize($conn, $_POST['name'] ?? '');
    $email   = sanitize($conn, $_POST['email'] ?? '');
    $phone   = sanitize($conn, $_POST['phone'] ?? '');
    $address = sanitize($conn, $_POST['address'] ?? '');
    $date    = sanitize($conn, $_POST['membership_date'] ?? date('Y-m-d'));
    $status  = in_array($_POST['status']??'', ['active','inactive']) ? $_POST['status'] : 'active';

    if (!$name || !$email) {
        $error = 'Name and Email are required.';
    } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $check = mysqli_query($conn,"SELECT id FROM members WHERE email='$email'");
        if (mysqli_num_rows($check)>0) {
            $error = 'A member with this email already exists.';
        } else {
            $sql = "INSERT INTO members (name,email,phone,address,membership_date,status) VALUES ('$name','$email','$phone','$address','$date','$status')";
            if (mysqli_query($conn,$sql)) {
                $_SESSION['msg']="Member \"$name\" added successfully!"; $_SESSION['msg_type']='success';
                redirect(SITE_URL.'/admin/members.php');
            } else {
                $error='Database error: '.mysqli_error($conn);
            }
        }
    }
}

include 'includes/sidebar.php';
?>

<?php if($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

<div class="page-card" style="max-width:600px;">
    <div class="page-card-header">
        <div class="page-card-title">👤 Add New Member</div>
        <a href="members.php" class="btn btn-outline btn-sm">← Back</a>
    </div>
    <form method="POST">
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Full Name *</label>
                <input type="text" name="name" class="form-control" required value="<?php echo htmlspecialchars($_POST['name']??''); ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Email *</label>
                <input type="email" name="email" class="form-control" required value="<?php echo htmlspecialchars($_POST['email']??''); ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Phone</label>
                <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($_POST['phone']??''); ?>" placeholder="0300-0000000">
            </div>
            <div class="form-group">
                <label class="form-label">Membership Date</label>
                <input type="date" name="membership_date" class="form-control" value="<?php echo $_POST['membership_date']??date('Y-m-d'); ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="form-label">Address</label>
            <textarea name="address" class="form-control" rows="3"><?php echo htmlspecialchars($_POST['address']??''); ?></textarea>
        </div>
        <div class="form-group">
            <label class="form-label">Status</label>
            <select name="status" class="form-control">
                <option value="active" <?php echo (($_POST['status']??'active')==='active')?'selected':''; ?>>Active</option>
                <option value="inactive" <?php echo (($_POST['status']??'')==='inactive')?'selected':''; ?>>Inactive</option>
            </select>
        </div>
        <div style="display:flex;gap:0.8rem;">
            <button type="submit" class="btn btn-primary">✅ Add Member</button>
            <a href="members.php" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
