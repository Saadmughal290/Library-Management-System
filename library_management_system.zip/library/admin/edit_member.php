<?php
require_once '../includes/config.php';
$page_title = 'Edit Member';
$error = '';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$member = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM members WHERE id=$id"));
if (!$member) redirect(SITE_URL.'/admin/members.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = sanitize($conn, $_POST['name']??'');
    $email   = sanitize($conn, $_POST['email']??'');
    $phone   = sanitize($conn, $_POST['phone']??'');
    $address = sanitize($conn, $_POST['address']??'');
    $date    = sanitize($conn, $_POST['membership_date']??'');
    $status  = in_array($_POST['status']??'',['active','inactive'])?$_POST['status']:'active';

    if (!$name||!$email) { $error='Name and Email required.'; }
    elseif (!filter_var($_POST['email'],FILTER_VALIDATE_EMAIL)) { $error='Invalid email.'; }
    else {
        $check=mysqli_query($conn,"SELECT id FROM members WHERE email='$email' AND id!=$id");
        if(mysqli_num_rows($check)>0) { $error='Email already used by another member.'; }
        else {
            mysqli_query($conn,"UPDATE members SET name='$name',email='$email',phone='$phone',address='$address',membership_date='$date',status='$status' WHERE id=$id");
            $_SESSION['msg']='Member updated!'; $_SESSION['msg_type']='success';
            redirect(SITE_URL.'/admin/members.php');
        }
    }
    $member=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM members WHERE id=$id"));
}

include 'includes/sidebar.php';
?>

<?php if($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

<div class="page-card" style="max-width:600px;">
    <div class="page-card-header">
        <div class="page-card-title">✏️ Edit Member</div>
        <a href="members.php" class="btn btn-outline btn-sm">← Back</a>
    </div>
    <form method="POST">
        <div class="form-row">
            <div class="form-group"><label class="form-label">Full Name *</label><input type="text" name="name" class="form-control" required value="<?php echo htmlspecialchars($member['name']); ?>"></div>
            <div class="form-group"><label class="form-label">Email *</label><input type="email" name="email" class="form-control" required value="<?php echo htmlspecialchars($member['email']); ?>"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($member['phone']); ?>"></div>
            <div class="form-group"><label class="form-label">Membership Date</label><input type="date" name="membership_date" class="form-control" value="<?php echo $member['membership_date']; ?>"></div>
        </div>
        <div class="form-group"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="3"><?php echo htmlspecialchars($member['address']); ?></textarea></div>
        <div class="form-group">
            <label class="form-label">Status</label>
            <select name="status" class="form-control">
                <option value="active" <?php echo $member['status']==='active'?'selected':''; ?>>Active</option>
                <option value="inactive" <?php echo $member['status']==='inactive'?'selected':''; ?>>Inactive</option>
            </select>
        </div>
        <div style="display:flex;gap:0.8rem;">
            <button type="submit" class="btn btn-primary">💾 Update</button>
            <a href="members.php" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
