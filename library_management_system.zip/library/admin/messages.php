<?php
require_once '../includes/config.php';
$page_title = 'Contact Messages';

if (isset($_GET['delete'])) {
    mysqli_query($conn,"DELETE FROM contact_messages WHERE id=".(int)$_GET['delete']);
    $_SESSION['msg']='Message deleted.'; $_SESSION['msg_type']='success';
    redirect(SITE_URL.'/admin/messages.php');
}
if (isset($_GET['read'])) {
    mysqli_query($conn,"UPDATE contact_messages SET is_read=1 WHERE id=".(int)$_GET['read']);
    redirect(SITE_URL.'/admin/messages.php');
}

$msg=$_SESSION['msg']??''; $msg_type=$_SESSION['msg_type']??'success';
unset($_SESSION['msg'],$_SESSION['msg_type']);

$messages=mysqli_query($conn,"SELECT * FROM contact_messages ORDER BY created_at DESC");

include 'includes/sidebar.php';
?>

<?php if($msg): ?><div class="alert alert-<?php echo $msg_type; ?>"><?php echo $msg; ?></div><?php endif; ?>

<div class="page-card">
    <div class="page-card-header">
        <div class="page-card-title">✉️ Contact Messages</div>
        <span style="font-size:0.85rem;color:var(--slate);"><?php echo mysqli_num_rows($messages); ?> total</span>
    </div>

    <?php if(mysqli_num_rows($messages)===0): ?>
    <div class="alert alert-info">No messages yet.</div>
    <?php else: ?>

    <div style="display:flex;flex-direction:column;gap:1rem;">
    <?php while($m=mysqli_fetch_assoc($messages)): ?>
    <div style="background:<?php echo $m['is_read']?'#fff':'#fffbf0'; ?>;border:1px solid var(--parchment-dark);border-radius:8px;padding:1.2rem;border-left:4px solid <?php echo $m['is_read']?'var(--parchment-dark)':'var(--gold)'; ?>;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:0.5rem;margin-bottom:0.8rem;">
            <div>
                <strong><?php echo htmlspecialchars($m['name']); ?></strong>
                <span style="color:#888;font-size:0.85rem;margin-left:0.5rem;"><?php echo htmlspecialchars($m['email']); ?></span>
                <?php if(!$m['is_read']): ?><span class="badge badge-unread" style="margin-left:0.5rem;">New</span><?php endif; ?>
            </div>
            <div style="display:flex;gap:0.5rem;align-items:center;">
                <small style="color:#aaa;"><?php echo date('d M Y, g:i A',strtotime($m['created_at'])); ?></small>
                <?php if(!$m['is_read']): ?><a href="messages.php?read=<?php echo $m['id']; ?>" class="btn btn-outline btn-sm">Mark Read</a><?php endif; ?>
                <a href="messages.php?delete=<?php echo $m['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirmDelete('Delete this message?')">🗑️</a>
            </div>
        </div>
        <?php if($m['subject']): ?><div style="font-weight:600;margin-bottom:0.4rem;font-size:0.95rem;">📌 <?php echo htmlspecialchars($m['subject']); ?></div><?php endif; ?>
        <p style="color:#555;font-size:0.9rem;line-height:1.7;"><?php echo nl2br(htmlspecialchars($m['message'])); ?></p>
    </div>
    <?php endwhile; ?>
    </div>

    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
