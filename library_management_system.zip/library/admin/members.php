<?php
require_once '../includes/config.php';
$page_title = 'Manage Members';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "DELETE FROM members WHERE id=$id");
    $_SESSION['msg'] = 'Member deleted.'; $_SESSION['msg_type'] = 'success';
    redirect(SITE_URL . '/admin/members.php');
}

$msg = $_SESSION['msg'] ?? ''; $msg_type = $_SESSION['msg_type'] ?? 'success';
unset($_SESSION['msg'], $_SESSION['msg_type']);

$search = isset($_GET['search']) ? sanitize($conn, $_GET['search']) : '';
$where = $search ? "WHERE name LIKE '%$search%' OR email LIKE '%$search%' OR phone LIKE '%$search%'" : "";

$per_page=10; $page_num=isset($_GET['page'])?max(1,(int)$_GET['page']):1; $offset=($page_num-1)*$per_page;
$total=mysqli_fetch_row(mysqli_query($conn,"SELECT COUNT(*) FROM members $where"))[0];
$total_pages=ceil($total/$per_page);
$members=mysqli_query($conn,"SELECT m.*,(SELECT COUNT(*) FROM borrow_records br WHERE br.member_id=m.id AND br.status='borrowed') as active_borrows FROM members m $where ORDER BY m.name ASC LIMIT $per_page OFFSET $offset");

include 'includes/sidebar.php';
?>

<?php if($msg): ?><div class="alert alert-<?php echo $msg_type; ?>"><?php echo $msg; ?></div><?php endif; ?>

<div class="page-card">
    <div class="page-card-header">
        <div class="page-card-title">👥 All Members (<?php echo $total; ?>)</div>
        <a href="add_member.php" class="btn btn-primary">👤 Add Member</a>
    </div>

    <form method="GET" class="search-bar">
        <input type="text" id="tableSearch" name="search" class="form-control" placeholder="Search by name, email, or phone..." value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if($search): ?><a href="members.php" class="btn btn-outline">Clear</a><?php endif; ?>
    </form>

    <div class="table-container">
        <table>
            <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th>Borrows</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
            <?php if(mysqli_num_rows($members)===0): ?>
            <tr><td colspan="8" style="text-align:center;padding:2rem;color:#888;">No members found.</td></tr>
            <?php else: while($m=mysqli_fetch_assoc($members)): ?>
            <tr>
                <td><?php echo $m['id']; ?></td>
                <td><strong><?php echo htmlspecialchars($m['name']); ?></strong></td>
                <td><?php echo htmlspecialchars($m['email']); ?></td>
                <td><?php echo htmlspecialchars($m['phone']); ?></td>
                <td><?php echo date('d M Y',strtotime($m['membership_date'])); ?></td>
                <td><?php echo $m['active_borrows']>0?"<span class='badge badge-borrowed'>{$m['active_borrows']}</span>":'—'; ?></td>
                <td><span class="badge badge-<?php echo $m['status']; ?>"><?php echo ucfirst($m['status']); ?></span></td>
                <td>
                    <div class="actions">
                        <a href="edit_member.php?id=<?php echo $m['id']; ?>" class="btn btn-outline btn-sm">✏️</a>
                        <a href="members.php?delete=<?php echo $m['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirmDelete('Delete this member and all their records?')">🗑️</a>
                    </div>
                </td>
            </tr>
            <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($total_pages>1): ?>
    <div class="pagination">
        <?php if($page_num>1): ?><a href="?page=<?php echo $page_num-1; ?>&search=<?php echo urlencode($search); ?>">← Prev</a><?php endif; ?>
        <?php for($i=1;$i<=$total_pages;$i++): ?><a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>" class="<?php echo $i===$page_num?'active':''; ?>"><?php echo $i; ?></a><?php endfor; ?>
        <?php if($page_num<$total_pages): ?><a href="?page=<?php echo $page_num+1; ?>&search=<?php echo urlencode($search); ?>">Next →</a><?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
