    </div><!-- /content -->
</div><!-- /main-content -->
<script>
function confirmDelete(msg) { return confirm(msg || 'Delete this record?'); }
document.querySelectorAll('.alert').forEach(a => {
    setTimeout(() => { a.style.opacity='0'; a.style.transition='opacity 0.5s'; setTimeout(()=>a.remove(),500); }, 4000);
});
const si = document.getElementById('tableSearch');
if (si) si.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll('tbody tr').forEach(r => r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none');
});
</script>
</body>
</html>
