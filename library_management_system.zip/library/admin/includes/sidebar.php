<?php
// admin/includes/sidebar.php
requireAdmin();
$cur = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' — Admin | LibraVault' : 'Admin | LibraVault'; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-logo">
        <span class="icon">📚</span>
        <strong>LibraVault</strong>
        <small>Admin Panel</small>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section">Main</div>
        <a href="<?php echo SITE_URL; ?>/admin/dashboard.php" class="<?php echo $cur==='dashboard'?'active':''; ?>">
            <span class="icon">🏠</span> Dashboard
        </a>

        <div class="nav-section">Library</div>
        <a href="<?php echo SITE_URL; ?>/admin/books.php" class="<?php echo $cur==='books'?'active':''; ?>">
            <span class="icon">📚</span> Books
        </a>
        <a href="<?php echo SITE_URL; ?>/admin/add_book.php" class="<?php echo $cur==='add_book'?'active':''; ?>">
            <span class="icon">➕</span> Add Book
        </a>
        <a href="<?php echo SITE_URL; ?>/admin/members.php" class="<?php echo $cur==='members'?'active':''; ?>">
            <span class="icon">👥</span> Members
        </a>
        <a href="<?php echo SITE_URL; ?>/admin/add_member.php" class="<?php echo $cur==='add_member'?'active':''; ?>">
            <span class="icon">👤</span> Add Member
        </a>

        <div class="nav-section">Transactions</div>
        <a href="<?php echo SITE_URL; ?>/admin/borrows.php" class="<?php echo $cur==='borrows'?'active':''; ?>">
            <span class="icon">🔄</span> Borrow Records
        </a>
        <a href="<?php echo SITE_URL; ?>/admin/issue_book.php" class="<?php echo $cur==='issue_book'?'active':''; ?>">
            <span class="icon">📤</span> Issue Book
        </a>

        <div class="nav-section">More</div>
        <a href="<?php echo SITE_URL; ?>/admin/messages.php" class="<?php echo $cur==='messages'?'active':''; ?>">
            <span class="icon">✉️</span> Messages
        </a>
        <a href="<?php echo SITE_URL; ?>/index.php" target="_blank">
            <span class="icon">🌐</span> View Website
        </a>
    </nav>

    <div class="sidebar-bottom">
        <a href="<?php echo SITE_URL; ?>/admin/logout.php">
            <span>🚪</span> Logout (<?php echo htmlspecialchars($_SESSION['admin_username']); ?>)
        </a>
    </div>
</aside>

<div class="main-content">
    <div class="topbar">
        <h2><?php echo isset($page_title) ? $page_title : 'Dashboard'; ?></h2>
        <div class="topbar-right">
            <span>👋 Welcome, <?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?></span>
            <span class="admin-badge">Administrator</span>
        </div>
    </div>
    <div class="content">
