<?php
require_once '../includes/config.php';
$page_title = 'Borrow Records';

// Auto-update overdue
mysqli_query($conn,"UPDATE borrow_records SET status='overdue' WHERE status='borrowed' AND due_date < CURDATE()");

// Return book
if (isset($_GET['return'])) {
    $id=(int)$_GET['return'];
    $rec=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM borrow_records WHERE id=$id"));
    if ($rec && $rec['status']!=='returned') {
        $today=date('Y-m-d');
        $fine=0;
        if ($today>$rec['due_date']) {
            $diff=abs((strtotime($today)-strtotime($rec['due_date']))/86400);
            $fine=round($diff*FINE_PER_DAY,2);
        }
        mysqli_query($conn,"UPDATE borrow_records SET status='returned',return_date='$today',fine=$fine WHERE id=$id");
        mysqli_query($conn,"UPDATE books SET available_copies=available_copies+1 WHERE id={$rec['book_id']}");
        $_SESSION['msg']="Book returned. Fine: PKR $fine"; $_SESSION['msg_type']='success';
    }
    redirect(SITE_URL.'/admin/borrows.php');
}

// Delete
if (isset($_GET['delete'])) {
    $id=(int)$_GET['delete'];
    $rec=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM borrow_records WHERE id=$id"));
    if ($rec && $rec['status']!=='returned') {
        mysqli_query($conn,"UPDATE books SET available_copies=available_copies+1 WHERE id={$rec['book_id']}");
    }
    mysqli_query($conn,"DELETE FROM borrow_records WHERE id=$id");
    $_SESSION['msg']='Record deleted.'; $_SESSION['msg_type']='success';
    redirect(SITE_URL.'/admin/borrows.php');
}

$msg=$_SESSION['msg']??''; $msg_type=$_SESSION['msg_type']??'success';
unset($_SESSION['msg'],$_SESSION['msg_type']);

// Filter
$status_filter=isset($_GET['status'])?sanitize($conn,$_GET['status']):'';
$search=isset($_GET['search'])?sanitize($conn,$_GET['search']):'';

$where="WHERE 1=1";
if ($status_filter) $where.=" AND br.status='$status_filter'";
if ($search) $where.=" AND (m.name LIKE '%$search%' OR b.title LIKE '%$search%')";

$per_page=12; $page_num=isset($_GET['page'])?max(1,(int)$_GET['page']):1; $offset=($page_num-1)*$per_page;
$total=mysqli_fetch_row(mysqli_query($conn,"SELECT COUNT(*) FROM borrow_records br JOIN members m ON br.member_id=m.id JOIN books b ON br.book_id=b.id $where"))[0];
$total_pages=ceil($total/$per_page);

$records=mysqli_query($conn,"
    SELECT br.*, m.name as member_name, b.title as book_title, b.author
    FROM borrow_records br
    JOIN members m ON br.member_id=m.id
    JOIN books b ON br.book_id=b.id
    $where ORDER BY br.created_at DESC LIMIT $per_page OFFSET $offset
");

include 'includes/sidebar.php';
?>

<?php if($msg): ?><div class="alert alert-<?php echo $msg_type; ?>"><?php echo $msg; ?></div><?php endif; ?>

<div class="page-card">
    <div class="page-card-header">
        <div class="page-card-title">🔄 Borrow Records (<?php echo $total; ?>)</div>
        <a href="issue_book.php" class="btn btn-primary">📤 Issue Book</a>
    </div>

    <form method="GET" class="search-bar">
        <input type="text" name="search" class="form-control" placeholder="Search member or book..." value="<?php echo htmlspecialchars($search); ?>">
        <select name="status" class="form-control" style="width:140px;">
            <option value="">All Status</option>
            <option value="borrowed" <?php echo $status_filter==='borrowed'?'selected':''; ?>>Borrowed</option>
            <option value="returned" <?php echo $status_filter==='returned'?'selected':''; ?>>Returned</option>
            <option value="overdue" <?php echo $status_filter==='overdue'?'selected':''; ?>>Overdue</option>
        </select>
        <button type="submit" class="btn btn-primary">Filter</button>
        <?php if($search||$status_filter): ?><a href="borrows.php" class="btn btn-outline">Clear</a><?php endif; ?>
    </form>

    <div class="table-container">
        <table>
            <thead><tr><th>ID</th><th>Member</th><th>Book</th><th>Borrow Date</th><th>Due Date</th><th>Return Date</th><th>Fine</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
            <?php if(mysqli_num_rows($records)===0): ?>
            <tr><td colspan="9" style="text-align:center;padding:2rem;color:#888;">No records found.</td></tr>
            <?php else: while($r=mysqli_fetch_assoc($records)): ?>
            <tr>
                <td><?php echo $r['id']; ?></td>
                <td><?php echo htmlspecialchars($r['member_name']); ?></td>
                <td><strong><?php echo htmlspecialchars($r['book_title']); ?></strong><br><small style="color:#888;"><?php echo htmlspecialchars($r['author']); ?></small></td>
                <td><?php echo date('d M Y',strtotime($r['borrow_date'])); ?></td>
                <td><?php echo date('d M Y',strtotime($r['due_date'])); ?></td>
                <td><?php echo $r['return_date']?date('d M Y',strtotime($r['return_date'])):'—'; ?></td>
                <td><?php echo $r['fine']>0?"<span style='color:var(--crimson);font-weight:600;'>PKR {$r['fine']}</span>":'—'; ?></td>
                <td><span class="badge badge-<?php echo $r['status']; ?>"><?php echo ucfirst($r['status']); ?></span></td>
                <td>
                    <div class="actions">
                    <?php if($r['status']!=='returned'): ?>
                        <a href="borrows.php?return=<?php echo $r['id']; ?>" class="btn btn-success btn-sm" onclick="return confirm('Mark as returned?')">↩️ Return</a>
                    <?php endif; ?>
                        <a href="borrows.php?delete=<?php echo $r['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirmDelete()">🗑️</a>
                    </div>
                </td>
            </tr>
            <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($total_pages>1): ?>
    <div class="pagination">
        <?php if($page_num>1): ?><a href="?page=<?php echo $page_num-1; ?>&status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>">← Prev</a><?php endif; ?>
        <?php for($i=1;$i<=$total_pages;$i++): ?><a href="?page=<?php echo $i; ?>&status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>" class="<?php echo $i===$page_num?'active':''; ?>"><?php echo $i; ?></a><?php endfor; ?>
        <?php if($page_num<$total_pages): ?><a href="?page=<?php echo $page_num+1; ?>&status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>">Next →</a><?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
