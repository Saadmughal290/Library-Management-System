<?php
require_once '../includes/config.php';
$page_title = 'Issue Book';
$error = '';

// Fetch active members and available books
$members_res = mysqli_query($conn,"SELECT id,name,email FROM members WHERE status='active' ORDER BY name");
$books_res   = mysqli_query($conn,"SELECT id,title,author,available_copies FROM books WHERE available_copies>0 ORDER BY title");

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $member_id = (int)($_POST['member_id']??0);
    $book_id   = (int)($_POST['book_id']??0);
    $borrow    = sanitize($conn,$_POST['borrow_date']??date('Y-m-d'));
    $due       = sanitize($conn,$_POST['due_date']??'');

    if (!$member_id||!$book_id||!$due) {
        $error='Please fill all required fields.';
    } else {
        // Check if member already has this book
        $dup=mysqli_query($conn,"SELECT id FROM borrow_records WHERE member_id=$member_id AND book_id=$book_id AND status='borrowed'");
        if (mysqli_num_rows($dup)>0) {
            $error='This member already has this book borrowed.';
        } else {
            mysqli_query($conn,"INSERT INTO borrow_records (member_id,book_id,borrow_date,due_date,status) VALUES ($member_id,$book_id,'$borrow','$due','borrowed')");
            mysqli_query($conn,"UPDATE books SET available_copies=available_copies-1 WHERE id=$book_id");
            $_SESSION['msg']='Book issued successfully!'; $_SESSION['msg_type']='success';
            redirect(SITE_URL.'/admin/borrows.php');
        }
    }
}

include 'includes/sidebar.php';
?>

<?php if($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

<div class="page-card" style="max-width:600px;">
    <div class="page-card-header">
        <div class="page-card-title">📤 Issue Book to Member</div>
        <a href="borrows.php" class="btn btn-outline btn-sm">← Borrow Records</a>
    </div>
    <form method="POST">
        <div class="form-group">
            <label class="form-label">Select Member *</label>
            <select name="member_id" class="form-control" required>
                <option value="">— Choose Member —</option>
                <?php while($m=mysqli_fetch_assoc($members_res)): ?>
                <option value="<?php echo $m['id']; ?>" <?php echo (($_POST['member_id']??0)==$m['id'])?'selected':''; ?>>
                    <?php echo htmlspecialchars($m['name']); ?> (<?php echo htmlspecialchars($m['email']); ?>)
                </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Select Book *</label>
            <select name="book_id" class="form-control" required>
                <option value="">— Choose Book —</option>
                <?php while($b=mysqli_fetch_assoc($books_res)): ?>
                <option value="<?php echo $b['id']; ?>" <?php echo (($_POST['book_id']??0)==$b['id'])?'selected':''; ?>>
                    <?php echo htmlspecialchars($b['title']); ?> by <?php echo htmlspecialchars($b['author']); ?> (<?php echo $b['available_copies']; ?> left)
                </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Borrow Date *</label>
                <input type="date" name="borrow_date" class="form-control" value="<?php echo $_POST['borrow_date']??date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Due Date *</label>
                <input type="date" name="due_date" class="form-control" value="<?php echo $_POST['due_date']??date('Y-m-d',strtotime('+14 days')); ?>" required>
            </div>
        </div>
        <div style="display:flex;gap:0.8rem;">
            <button type="submit" class="btn btn-primary">📤 Issue Book</button>
            <a href="borrows.php" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
