<?php
require_once '../includes/config.php';
$page_title = 'Add Book';
$error = $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title   = sanitize($conn, $_POST['title'] ?? '');
    $author  = sanitize($conn, $_POST['author'] ?? '');
    $isbn    = sanitize($conn, $_POST['isbn'] ?? '');
    $cat     = sanitize($conn, $_POST['category'] ?? '');
    $copies  = (int)($_POST['total_copies'] ?? 1);
    $year    = (int)($_POST['published_year'] ?? date('Y'));
    $desc    = sanitize($conn, $_POST['description'] ?? '');

    if (!$title || !$author || !$isbn) {
        $error = 'Title, Author, and ISBN are required.';
    } else {
        // Check ISBN unique
        $check = mysqli_query($conn, "SELECT id FROM books WHERE isbn='$isbn'");
        if (mysqli_num_rows($check) > 0) {
            $error = 'A book with this ISBN already exists.';
        } else {
            $sql = "INSERT INTO books (title,author,isbn,category,total_copies,available_copies,published_year,description)
                    VALUES ('$title','$author','$isbn','$cat',$copies,$copies,$year,'$desc')";
            if (mysqli_query($conn, $sql)) {
                $_SESSION['msg'] = "Book \"$title\" added successfully!";
                $_SESSION['msg_type'] = 'success';
                redirect(SITE_URL . '/admin/books.php');
            } else {
                $error = 'Database error: ' . mysqli_error($conn);
            }
        }
    }
}

include 'includes/sidebar.php';
?>

<?php if($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

<div class="page-card" style="max-width:700px;">
    <div class="page-card-header">
        <div class="page-card-title">➕ Add New Book</div>
        <a href="books.php" class="btn btn-outline btn-sm">← Back to Books</a>
    </div>

    <form method="POST">
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Title *</label>
                <input type="text" name="title" class="form-control" required value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Author *</label>
                <input type="text" name="author" class="form-control" required value="<?php echo htmlspecialchars($_POST['author'] ?? ''); ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">ISBN *</label>
                <input type="text" name="isbn" class="form-control" required value="<?php echo htmlspecialchars($_POST['isbn'] ?? ''); ?>" placeholder="e.g. 978-0000000000">
            </div>
            <div class="form-group">
                <label class="form-label">Category</label>
                <select name="category" class="form-control">
                    <?php foreach(['Fiction','Non-Fiction','Technology','Science','History','Self-Help','Dystopian','Biography','Other'] as $c): ?>
                    <option value="<?php echo $c; ?>" <?php echo (($_POST['category']??'')===$c)?'selected':''; ?>><?php echo $c; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Total Copies</label>
                <input type="number" name="total_copies" class="form-control" min="1" value="<?php echo htmlspecialchars($_POST['total_copies'] ?? '1'); ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Published Year</label>
                <input type="number" name="published_year" class="form-control" min="1000" max="<?php echo date('Y'); ?>" value="<?php echo htmlspecialchars($_POST['published_year'] ?? date('Y')); ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="4"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
        </div>
        <div style="display:flex;gap:0.8rem;">
            <button type="submit" class="btn btn-primary">✅ Save Book</button>
            <a href="books.php" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
