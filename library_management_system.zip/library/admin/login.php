<?php
require_once '../includes/config.php';

// Redirect if already logged in
if (isAdminLoggedIn()) {
    redirect(SITE_URL . '/admin/dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($conn, $_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
        $error = 'Please enter both username and password.';
    } else {
        $result = mysqli_query($conn, "SELECT * FROM admins WHERE username='$username' LIMIT 1");
        $admin = mysqli_fetch_assoc($result);

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_name'] = $admin['full_name'];
            redirect(SITE_URL . '/admin/dashboard.php');
        } else {
            $error = 'Invalid username or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login — LibraVault</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css">
</head>
<body>
<div class="login-page">
    <div class="login-box">
        <div class="login-logo">
            <span class="icon">📚</span>
            <h1>LibraVault</h1>
            <p>Admin Panel — Authorized Access Only</p>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" placeholder="Enter admin username" required autofocus value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;padding:0.8rem;justify-content:center;font-size:0.95rem;">Sign In →</button>
        </form>

        <p style="text-align:center;margin-top:1.5rem;font-size:0.82rem;color:#888;">
            Default: <code>admin</code> / <code>admin123</code><br>
            <small>(Update in admins table after first login)</small>
        </p>

        <p style="text-align:center;margin-top:1rem;">
            <a href="<?php echo SITE_URL; ?>/index.php" style="color:var(--gold);font-size:0.85rem;text-decoration:none;">← Back to Website</a>
        </p>
    </div>
</div>
</body>
</html>
