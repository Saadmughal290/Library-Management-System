<?php
require_once '../includes/config.php';
$page_title = 'Dashboard';

// Stats
$total_books     = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM books"))[0];
$total_members   = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM members"))[0];
$active_borrows  = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM borrow_records WHERE status='borrowed'"))[0];
$overdue         = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM borrow_records WHERE status='overdue' OR (status='borrowed' AND due_date < CURDATE())"))[0];
$total_returned  = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM borrow_records WHERE status='returned'"))[0];
$unread_msgs     = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM contact_messages WHERE is_read=0"))[0];

// Recent borrows
$recent = mysqli_query($conn, "
    SELECT br.*, m.name as member_name, b.title as book_title
    FROM borrow_records br
    JOIN members m ON br.member_id=m.id
    JOIN books b ON br.book_id=b.id
    ORDER BY br.created_at DESC LIMIT 8
");

// Update overdue status
mysqli_query($conn, "UPDATE borrow_records SET status='overdue' WHERE status='borrowed' AND due_date < CURDATE()");

include 'includes/sidebar.php';
?>

<!-- Stat Cards -->
<div class="stat-cards">
    <div class="stat-card">
        <div class="stat-icon gold">📚</div>
        <div><div class="stat-val"><?php echo $total_books; ?></div><div class="stat-lbl">Total Books</div></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">👥</div>
        <div><div class="stat-val"><?php echo $total_members; ?></div><div class="stat-lbl">Members</div></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon blue">🔄</div>
        <div><div class="stat-val"><?php echo $active_borrows; ?></div><div class="stat-lbl">Borrowed</div></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red">⚠️</div>
        <div><div class="stat-val"><?php echo $overdue; ?></div><div class="stat-lbl">Overdue</div></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green">✅</div>
        <div><div class="stat-val"><?php echo $total_returned; ?></div><div class="stat-lbl">Returned</div></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon gold">✉️</div>
        <div><div class="stat-val"><?php echo $unread_msgs; ?></div><div class="stat-lbl">Unread Messages</div></div>
    </div>
</div>

<!-- Quick Actions -->
<div class="page-card" style="margin-bottom:1.5rem;">
    <div class="page-card-title" style="margin-bottom:1rem;">⚡ Quick Actions</div>
    <div style="display:flex;gap:0.8rem;flex-wrap:wrap;">
        <a href="add_book.php" class="btn btn-primary">➕ Add Book</a>
        <a href="add_member.php" class="btn btn-success">👤 Add Member</a>
        <a href="issue_book.php" class="btn btn-outline">📤 Issue Book</a>
        <a href="borrows.php" class="btn btn-outline">🔄 Borrow Records</a>
        <a href="messages.php" class="btn btn-outline">✉️ Messages <?php if($unread_msgs>0): ?><span style="background:var(--crimson);color:#fff;border-radius:10px;padding:0 6px;font-size:0.75rem;"><?php echo $unread_msgs; ?></span><?php endif; ?></a>
    </div>
</div>

<!-- Recent Borrows -->
<div class="page-card">
    <div class="page-card-header">
        <div class="page-card-title">📋 Recent Borrow Records</div>
        <a href="borrows.php" class="btn btn-outline btn-sm">View All</a>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Member</th>
                    <th>Book</th>
                    <th>Borrow Date</th>
                    <th>Due Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($r = mysqli_fetch_assoc($recent)): ?>
            <tr>
                <td><?php echo $r['id']; ?></td>
                <td><?php echo htmlspecialchars($r['member_name']); ?></td>
                <td><?php echo htmlspecialchars($r['book_title']); ?></td>
                <td><?php echo date('d M Y', strtotime($r['borrow_date'])); ?></td>
                <td><?php echo date('d M Y', strtotime($r['due_date'])); ?></td>
                <td><span class="badge badge-<?php echo $r['status']; ?>"><?php echo ucfirst($r['status']); ?></span></td>
            </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
