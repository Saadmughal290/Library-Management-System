<?php
require_once '../includes/config.php';
$page_title = 'Edit Book';
$error = '';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$book = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM books WHERE id=$id"));
if (!$book) { redirect(SITE_URL . '/admin/books.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title   = sanitize($conn, $_POST['title'] ?? '');
    $author  = sanitize($conn, $_POST['author'] ?? '');
    $isbn    = sanitize($conn, $_POST['isbn'] ?? '');
    $cat     = sanitize($conn, $_POST['category'] ?? '');
    $copies  = (int)($_POST['total_copies'] ?? 1);
    $avail   = (int)($_POST['available_copies'] ?? 0);
    $year    = (int)($_POST['published_year'] ?? date('Y'));
    $desc    = sanitize($conn, $_POST['description'] ?? '');

    if (!$title || !$author || !$isbn) {
        $error = 'Title, Author, and ISBN are required.';
    } else {
        $check = mysqli_query($conn, "SELECT id FROM books WHERE isbn='$isbn' AND id!=$id");
        if (mysqli_num_rows($check) > 0) {
            $error = 'A different book with this ISBN already exists.';
        } else {
            $sql = "UPDATE books SET title='$title',author='$author',isbn='$isbn',category='$cat',
                    total_copies=$copies,available_copies=$avail,published_year=$year,description='$desc' WHERE id=$id";
            if (mysqli_query($conn, $sql)) {
                $_SESSION['msg'] = "Book updated successfully!";
                $_SESSION['msg_type'] = 'success';
                redirect(SITE_URL . '/admin/books.php');
            } else {
                $error = 'Database error: ' . mysqli_error($conn);
            }
        }
    }
    // Reload
    $book = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM books WHERE id=$id"));
}

include 'includes/sidebar.php';
?>

<?php if($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

<div class="page-card" style="max-width:700px;">
    <div class="page-card-header">
        <div class="page-card-title">✏️ Edit Book</div>
        <a href="books.php" class="btn btn-outline btn-sm">← Back</a>
    </div>

    <form method="POST">
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Title *</label>
                <input type="text" name="title" class="form-control" required value="<?php echo htmlspecialchars($book['title']); ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Author *</label>
                <input type="text" name="author" class="form-control" required value="<?php echo htmlspecialchars($book['author']); ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">ISBN *</label>
                <input type="text" name="isbn" class="form-control" required value="<?php echo htmlspecialchars($book['isbn']); ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Category</label>
                <select name="category" class="form-control">
                    <?php foreach(['Fiction','Non-Fiction','Technology','Science','History','Self-Help','Dystopian','Biography','Other'] as $c): ?>
                    <option value="<?php echo $c; ?>" <?php echo $book['category']===$c?'selected':''; ?>><?php echo $c; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Total Copies</label>
                <input type="number" name="total_copies" class="form-control" min="1" value="<?php echo $book['total_copies']; ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Available Copies</label>
                <input type="number" name="available_copies" class="form-control" min="0" value="<?php echo $book['available_copies']; ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Published Year</label>
                <input type="number" name="published_year" class="form-control" value="<?php echo $book['published_year']; ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="4"><?php echo htmlspecialchars($book['description']); ?></textarea>
        </div>
        <div style="display:flex;gap:0.8rem;">
            <button type="submit" class="btn btn-primary">💾 Update Book</button>
            <a href="books.php" class="btn btn-outline">Cancel</a>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
