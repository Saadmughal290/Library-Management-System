<?php
require_once '../includes/config.php';
$page_title = 'Manage Books';

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "DELETE FROM books WHERE id=$id");
    $_SESSION['msg'] = 'Book deleted successfully.';
    $_SESSION['msg_type'] = 'success';
    redirect(SITE_URL . '/admin/books.php');
}

$msg = $_SESSION['msg'] ?? ''; $msg_type = $_SESSION['msg_type'] ?? 'success';
unset($_SESSION['msg'], $_SESSION['msg_type']);

// Search
$search = isset($_GET['search']) ? sanitize($conn, $_GET['search']) : '';
$cat_filter = isset($_GET['category']) ? sanitize($conn, $_GET['category']) : '';

$where = "WHERE 1=1";
if ($search) $where .= " AND (title LIKE '%$search%' OR author LIKE '%$search%' OR isbn LIKE '%$search%')";
if ($cat_filter) $where .= " AND category='$cat_filter'";

// Pagination
$per_page = 10;
$page_num = isset($_GET['page']) ? max(1,(int)$_GET['page']) : 1;
$offset = ($page_num-1)*$per_page;
$total = mysqli_fetch_row(mysqli_query($conn,"SELECT COUNT(*) FROM books $where"))[0];
$total_pages = ceil($total/$per_page);

$books = mysqli_query($conn,"SELECT * FROM books $where ORDER BY title ASC LIMIT $per_page OFFSET $offset");
$cats_res = mysqli_query($conn,"SELECT DISTINCT category FROM books ORDER BY category");
$cats=[]; while($c=mysqli_fetch_row($cats_res)) $cats[]=$c[0];

include 'includes/sidebar.php';
?>

<?php if($msg): ?><div class="alert alert-<?php echo $msg_type; ?>"><?php echo $msg; ?></div><?php endif; ?>

<div class="page-card">
    <div class="page-card-header">
        <div class="page-card-title">📚 All Books (<?php echo $total; ?>)</div>
        <a href="add_book.php" class="btn btn-primary">➕ Add New Book</a>
    </div>

    <!-- Search -->
    <form method="GET" class="search-bar">
        <input type="text" id="tableSearch" name="search" class="form-control" placeholder="Search by title, author, ISBN..." value="<?php echo htmlspecialchars($search); ?>">
        <select name="category" class="form-control" style="width:160px;">
            <option value="">All Categories</option>
            <?php foreach($cats as $c): ?><option value="<?php echo $c; ?>" <?php echo $cat_filter===$c?'selected':''; ?>><?php echo $c; ?></option><?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary">Filter</button>
        <?php if($search||$cat_filter): ?><a href="books.php" class="btn btn-outline">Clear</a><?php endif; ?>
    </form>

    <div class="table-container">
        <table>
            <thead>
                <tr><th>ID</th><th>Title</th><th>Author</th><th>ISBN</th><th>Category</th><th>Copies</th><th>Available</th><th>Year</th><th>Actions</th></tr>
            </thead>
            <tbody>
            <?php if(mysqli_num_rows($books)===0): ?>
            <tr><td colspan="9" style="text-align:center;padding:2rem;color:#888;">No books found.</td></tr>
            <?php else: while($b=mysqli_fetch_assoc($books)): ?>
            <tr>
                <td><?php echo $b['id']; ?></td>
                <td><strong><?php echo htmlspecialchars($b['title']); ?></strong></td>
                <td><?php echo htmlspecialchars($b['author']); ?></td>
                <td><small><?php echo htmlspecialchars($b['isbn']); ?></small></td>
                <td><?php echo htmlspecialchars($b['category']); ?></td>
                <td><?php echo $b['total_copies']; ?></td>
                <td><span class="badge <?php echo $b['available_copies']>0?'badge-available':'badge-unavailable'; ?>"><?php echo $b['available_copies']; ?></span></td>
                <td><?php echo $b['published_year']; ?></td>
                <td>
                    <div class="actions">
                        <a href="edit_book.php?id=<?php echo $b['id']; ?>" class="btn btn-outline btn-sm">✏️ Edit</a>
                        <a href="books.php?delete=<?php echo $b['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirmDelete('Delete this book?')">🗑️</a>
                    </div>
                </td>
            </tr>
            <?php endwhile; endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if($total_pages>1): ?>
    <div class="pagination">
        <?php if($page_num>1): ?><a href="?page=<?php echo $page_num-1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($cat_filter); ?>">← Prev</a><?php endif; ?>
        <?php for($i=1;$i<=$total_pages;$i++): ?><a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($cat_filter); ?>" class="<?php echo $i===$page_num?'active':''; ?>"><?php echo $i; ?></a><?php endfor; ?>
        <?php if($page_num<$total_pages): ?><a href="?page=<?php echo $page_num+1; ?>&search=<?php echo urlencode($search); ?>&category=<?php echo urlencode($cat_filter); ?>">Next →</a><?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
