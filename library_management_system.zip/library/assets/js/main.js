// LibraVault — Main JavaScript

function toggleMenu() {
    document.querySelector('.nav-links').classList.toggle('open');
}

// Auto-dismiss alerts
document.querySelectorAll('.alert').forEach(alert => {
    setTimeout(() => { alert.style.opacity = '0'; alert.style.transition = 'opacity 0.5s'; setTimeout(() => alert.remove(), 500); }, 4000);
});

// Confirm delete
function confirmDelete(msg) {
    return confirm(msg || 'Are you sure you want to delete this record?');
}

// Animate stats on scroll
function animateCounters() {
    document.querySelectorAll('.stat-num').forEach(el => {
        const target = parseInt(el.dataset.target || el.innerText);
        let count = 0;
        const step = Math.ceil(target / 40);
        const timer = setInterval(() => {
            count = Math.min(count + step, target);
            el.innerText = count;
            if (count >= target) clearInterval(timer);
        }, 30);
    });
}

// Intersection Observer for stats
const statsBar = document.querySelector('.stats-bar');
if (statsBar) {
    const observer = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting) { animateCounters(); observer.disconnect(); }
    });
    observer.observe(statsBar);
}

// Search filter (client-side table filtering)
const searchInput = document.getElementById('tableSearch');
if (searchInput) {
    searchInput.addEventListener('input', function () {
        const q = this.value.toLowerCase();
        document.querySelectorAll('tbody tr').forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    });
}
