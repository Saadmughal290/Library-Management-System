<?php
require_once 'includes/config.php';
$page_title = 'Contact';
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($conn, $_POST['name'] ?? '');
    $email = sanitize($conn, $_POST['email'] ?? '');
    $subject = sanitize($conn, $_POST['subject'] ?? '');
    $message = sanitize($conn, $_POST['message'] ?? '');

    if (!$name || !$email || !$message) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $sql = "INSERT INTO contact_messages (name, email, subject, message) VALUES ('$name','$email','$subject','$message')";
        if (mysqli_query($conn, $sql)) {
            $success = 'Thank you! Your message has been sent. We will get back to you shortly.';
        } else {
            $error = 'Something went wrong. Please try again.';
        }
    }
}
?>
<?php include 'includes/header.php'; ?>

<div class="page-header">
    <h1>📬 Contact Us</h1>
    <p>We'd love to hear from you</p>
</div>

<section class="section">
    <div class="container">
        <div class="contact-grid">

            <!-- Contact Info -->
            <div>
                <h3>Get In Touch</h3>
                <p style="color:#666;margin-bottom:2rem;line-height:1.7;">Have a question about your membership, a book request, or just want to say hello? Fill out the form and we'll get back to you.</p>

                <div class="contact-item">
                    <span class="contact-icon">📍</span>
                    <div>
                        <strong>Address</strong>
                        <p style="color:#666;font-size:0.9rem;">FAST-NUCES, A.K. Brohi Road,<br>H-11/4, Islamabad, Pakistan</p>
                    </div>
                </div>
                <div class="contact-item">
                    <span class="contact-icon">📧</span>
                    <div>
                        <strong>Email</strong>
                        <p style="color:#666;font-size:0.9rem;">library@libravault.pk</p>
                    </div>
                </div>
                <div class="contact-item">
                    <span class="contact-icon">📞</span>
                    <div>
                        <strong>Phone</strong>
                        <p style="color:#666;font-size:0.9rem;">051-111-128-128 Ext. 302</p>
                    </div>
                </div>
                <div class="contact-item">
                    <span class="contact-icon">🕐</span>
                    <div>
                        <strong>Library Hours</strong>
                        <p style="color:#666;font-size:0.9rem;">Mon–Fri: 8:00 AM – 8:00 PM<br>Sat: 9:00 AM – 4:00 PM</p>
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="form-card" style="max-width:100%;">
                <h3 style="font-family:var(--font-display);font-size:1.4rem;margin-bottom:1.5rem;">Send a Message</h3>

                <?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
                <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

                <form method="POST">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Name *</label>
                            <input type="text" name="name" class="form-control" required value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email *</label>
                            <input type="email" name="email" class="form-control" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Subject</label>
                        <input type="text" name="subject" class="form-control" value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Message *</label>
                        <textarea name="message" class="form-control" rows="5" required><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width:100%;padding:0.85rem;">Send Message →</button>
                </form>
            </div>

        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
