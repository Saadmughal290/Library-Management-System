<?php
require_once 'includes/config.php';
$page_title = 'Home';

// Fetch stats
$total_books = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM books"))[0];
$total_members = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM members WHERE status='active'"))[0];
$total_borrows = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM borrow_records WHERE status='borrowed'"))[0];
$total_returned = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM borrow_records WHERE status='returned'"))[0];

// Fetch latest 6 books
$books_query = mysqli_query($conn, "SELECT * FROM books ORDER BY created_at DESC LIMIT 6");
?>
<?php include 'includes/header.php'; ?>

<!-- HERO -->
<section class="hero">
    <h1>LibraVault</h1>
    <p>A modern library management system — discover books, manage members, and track borrowings all in one place.</p>
    <div class="hero-btns">
        <a href="books.php" class="btn btn-primary">Browse Books</a>
        <a href="about.php" class="btn btn-outline">Learn More</a>
    </div>
</section>

<!-- STATS -->
<section class="stats-bar">
    <div class="stat-item">
        <span class="num stat-num" data-target="<?php echo $total_books; ?>"><?php echo $total_books; ?></span>
        <span>Total Books</span>
    </div>
    <div class="stat-item">
        <span class="num stat-num" data-target="<?php echo $total_members; ?>"><?php echo $total_members; ?></span>
        <span>Active Members</span>
    </div>
    <div class="stat-item">
        <span class="num stat-num" data-target="<?php echo $total_borrows; ?>"><?php echo $total_borrows; ?></span>
        <span>Books Borrowed</span>
    </div>
    <div class="stat-item">
        <span class="num stat-num" data-target="<?php echo $total_returned; ?>"><?php echo $total_returned; ?></span>
        <span>Books Returned</span>
    </div>
</section>

<!-- FEATURED BOOKS -->
<section class="section">
    <div class="container">
        <p class="section-subtitle">Recently Added</p>
        <h2 class="section-title">Featured Books</h2>
        <div class="divider"></div>

        <div class="card-grid">
            <?php while ($book = mysqli_fetch_assoc($books_query)): ?>
            <div class="card">
                <div class="card-cover">📖</div>
                <div class="card-body">
                    <div class="card-category"><?php echo htmlspecialchars($book['category']); ?></div>
                    <div class="card-title"><?php echo htmlspecialchars($book['title']); ?></div>
                    <div class="card-author">by <?php echo htmlspecialchars($book['author']); ?></div>
                    <p style="font-size:0.82rem;color:#666;line-height:1.5;">
                        <?php echo htmlspecialchars(substr($book['description'], 0, 90)) . '...'; ?>
                    </p>
                    <div class="card-footer">
                        <span class="badge <?php echo $book['available_copies'] > 0 ? 'badge-available' : 'badge-unavailable'; ?>">
                            <?php echo $book['available_copies'] > 0 ? $book['available_copies'] . ' Available' : 'Not Available'; ?>
                        </span>
                        <small style="color:#888;">ISBN: <?php echo $book['isbn']; ?></small>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>

        <div style="text-align:center;margin-top:2.5rem;">
            <a href="books.php" class="btn btn-primary">View All Books</a>
        </div>
    </div>
</section>

<!-- FEATURES -->
<section class="section" style="background:var(--ink);color:var(--parchment);">
    <div class="container" style="text-align:center;">
        <h2 class="section-title" style="color:var(--gold);">Why LibraVault?</h2>
        <div class="divider" style="margin:0.7rem auto 2.5rem;"></div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:2rem;margin-top:1rem;">
            <?php
            $features = [
                ['📚','Vast Collection','Browse thousands of books across multiple categories and genres.'],
                ['👥','Member Management','Track all library members, their history, and subscription status.'],
                ['🔄','Borrow & Return','Simple and efficient book borrowing and return tracking system.'],
                ['⚠️','Overdue Alerts','Automatic overdue detection and fine calculation for late returns.'],
                ['🔍','Smart Search','Find any book or member instantly with powerful search filters.'],
                ['🛡️','Secure Admin','Password-protected admin panel for full record management.'],
            ];
            foreach ($features as $f): ?>
            <div style="padding:1.5rem;background:rgba(255,255,255,0.04);border-radius:8px;border:1px solid rgba(201,168,76,0.15);">
                <div style="font-size:2.5rem;margin-bottom:1rem;"><?php echo $f[0]; ?></div>
                <h3 style="font-family:var(--font-display);color:var(--gold);margin-bottom:0.5rem;font-size:1.1rem;"><?php echo $f[1]; ?></h3>
                <p style="opacity:0.65;font-size:0.88rem;line-height:1.6;"><?php echo $f[2]; ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
