<?php
require_once 'includes/config.php';
$page_title = 'About';
?>
<?php include 'includes/header.php'; ?>

<div class="page-header">
    <h1>About LibraVault</h1>
    <p>Our story, mission, and the team behind the system</p>
</div>

<section class="section">
    <div class="container">
        <div class="about-grid">
            <div>
                <p class="section-subtitle">Who We Are</p>
                <h2 class="section-title">A Modern Library for the Digital Age</h2>
                <div class="divider"></div>
                <p style="color:#555;line-height:1.8;margin-bottom:1rem;">
                    LibraVault is a comprehensive library management system developed as part of <strong>CSC 337 — Web Programming Languages</strong> at FAST-NUCES. It is designed to streamline the day-to-day operations of a modern library.
                </p>
                <p style="color:#555;line-height:1.8;margin-bottom:1rem;">
                    Our system handles everything from maintaining a book catalogue, managing member registrations, tracking borrow and return records, to calculating overdue fines — all within a clean and intuitive interface.
                </p>
                <p style="color:#555;line-height:1.8;">
                    Built with <strong>PHP + MySQL</strong>, it demonstrates the power of full-stack web development including CRUD operations, session-based authentication, and relational database design.
                </p>
            </div>
            <div class="about-img">📚</div>
        </div>
    </div>
</section>

<section class="section" style="background:var(--parchment-dark);">
    <div class="container" style="text-align:center;">
        <h2 class="section-title">Technology Stack</h2>
        <div class="divider" style="margin:0.7rem auto 2rem;"></div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1.5rem;max-width:900px;margin:0 auto;">
            <?php
            $stack = [
                ['🐘','PHP 8','Server-side scripting & session management'],
                ['🗄️','MySQL','Relational database with CRUD operations'],
                ['🎨','HTML5 / CSS3','Responsive, modern frontend design'],
                ['⚡','JavaScript','Dynamic interactions & client filtering'],
                ['🔒','Bcrypt','Secure password hashing for admin auth'],
                ['📄','Playfair Display','Typography from Google Fonts'],
            ];
            foreach ($stack as $s): ?>
            <div style="background:var(--cream);padding:1.5rem;border-radius:8px;border:1px solid var(--parchment-dark);box-shadow:0 2px 8px var(--shadow);">
                <div style="font-size:2rem;margin-bottom:0.7rem;"><?php echo $s[0]; ?></div>
                <strong style="font-family:var(--font-display);font-size:1rem;"><?php echo $s[1]; ?></strong>
                <p style="font-size:0.82rem;color:#666;margin-top:0.4rem;line-height:1.5;"><?php echo $s[2]; ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <h2 class="section-title" style="text-align:center;">Database Design</h2>
        <div class="divider" style="margin:0.7rem auto 2rem;"></div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:1.5rem;max-width:900px;margin:0 auto;">
            <?php
            $tables = [
                ['📋','admins','Stores admin login credentials and profile information.'],
                ['📚','books','Book catalogue with copies, categories, and metadata.'],
                ['👥','members','Library members with contact info and status.'],
                ['🔄','borrow_records','Links members to books; tracks borrow/return dates and fines.'],
                ['✉️','contact_messages','Stores visitor contact form submissions for admin review.'],
            ];
            foreach ($tables as $t): ?>
            <div style="background:var(--ink);color:var(--parchment);padding:1.5rem;border-radius:8px;border-top:3px solid var(--gold);">
                <div style="font-size:1.8rem;margin-bottom:0.7rem;"><?php echo $t[0]; ?></div>
                <code style="color:var(--gold);font-size:0.9rem;"><?php echo $t[1]; ?></code>
                <p style="font-size:0.82rem;opacity:0.7;margin-top:0.4rem;line-height:1.5;"><?php echo $t[2]; ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
